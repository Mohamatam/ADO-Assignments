﻿using System.Web;
using System.Web.Mvc;

namespace Entity_Assignment_2._2
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
